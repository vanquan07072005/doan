/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nhanguifile;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;

public class MainFrame extends JFrame {
    private JButton uploadButton, downloadButton;
    private JTextArea fileListArea;

    public MainFrame() {
        setTitle("File Transfer App");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        fileListArea = new JTextArea();
        fileListArea.setEditable(false);
        add(new JScrollPane(fileListArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        uploadButton = new JButton("Upload File");
        downloadButton = new JButton("Download File");

        buttonPanel.add(uploadButton);
        buttonPanel.add(downloadButton);
        add(buttonPanel, BorderLayout.SOUTH);

        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                uploadFile();
            }
        });

        downloadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                downloadFile();
            }
        });

        loadFileList();
    }

    private void uploadFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            saveFileToDatabase(file);
            loadFileList();
        }
    }

    private void saveFileToDatabase(File file) {
        String query = "INSERT INTO Files (FileName, FileData, UploadedBy) VALUES (?, ?, 1)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, file.getName());
            stmt.setBytes(2, readFileToByteArray(file));

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "File uploaded successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private byte[] readFileToByteArray(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return fis.readAllBytes();
        }
    }

    private void downloadFile() {
        String fileName = JOptionPane.showInputDialog(this, "Enter file name to download:");
        if (fileName != null && !fileName.isEmpty()) {
            retrieveFileFromDatabase(fileName);
        }
    }

    private void retrieveFileFromDatabase(String fileName) {
        String query = "SELECT FileData FROM Files WHERE FileName = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, fileName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                byte[] fileData = rs.getBytes("FileData");
                saveByteArrayToFile(fileData, fileName);
                JOptionPane.showMessageDialog(this, "File downloaded successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "File not found!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveByteArrayToFile(byte[] data, String fileName) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            fos.write(data);
        }
    }

    private void loadFileList() {
        String query = "SELECT FileName FROM Files";
        StringBuilder fileList = new StringBuilder();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                fileList.append(rs.getString("FileName")).append("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        fileListArea.setText(fileList.toString());
    }
}
public class MainFrame {
    
}
