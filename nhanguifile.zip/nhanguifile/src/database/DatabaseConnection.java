/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database; // Đặt package nếu bạn muốn tổ chức mã nguồn

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Thông tin kết nối
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=FileTransferDB";
    private static final String USER = "sa"; // Thay bằng tên người dùng của bạn
    private static final String PASSWORD = "manhlong"; // Thay bằng mật khẩu của bạn

    /**
     * Phương thức để lấy kết nối đến cơ sở dữ liệu
     * @return Connection object hoặc null nếu lỗi
     */
    public static Connection getConnection() {
        try {
            // Đăng ký driver (không bắt buộc với JDBC 4.0+)
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Tạo và trả về kết nối
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error connecting to the database!");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Phương thức kiểm tra kết nối
     */
    public static void testConnection() {
        try (Connection conn = getConnection()) {
            if (conn != null) {
                System.out.println("Connected to the database successfully!");
            } else {
                System.out.println("Failed to connect to the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Kiểm tra kết nối
        testConnection();
    }
}
public class DatabaseConnection {
    
}
